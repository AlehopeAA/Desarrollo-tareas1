import { grayColor } from 'assets/jss/material-ui-react'

const gridSystemStyle = {
  title: {
    color: grayColor[2],
    textDecoration: 'none',
  },
}

export default gridSystemStyle
