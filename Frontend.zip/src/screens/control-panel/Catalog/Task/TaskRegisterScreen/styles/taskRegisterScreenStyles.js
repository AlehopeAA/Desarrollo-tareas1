const styles = {
  selectableInput: {
    '&:before': {
      borderBottom: '1px solid #d2d2d2',
    },
  },
}

export default styles
