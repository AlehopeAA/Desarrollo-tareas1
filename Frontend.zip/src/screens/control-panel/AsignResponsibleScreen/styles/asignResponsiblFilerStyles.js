const asignResponsibleStyles = {}

export default asignResponsibleStyles
